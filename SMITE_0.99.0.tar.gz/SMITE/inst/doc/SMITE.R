## ---- warning=FALSE, message=FALSE, eval=T, tidy.opts=list(blank=FALSE, width.cutoff=50), echo=TRUE, results='hide'----
options(stringsAsFactors=FALSE)
library(SMITE)

## ---- tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=60), eval=T----
## Load methylation data ##
data(methylationdata)

## Replace zeros with minimum non-zero p-value ##
methylation<-replaceZeros(outdata = methylation, column = 5)

## Remove NAs from p-value column ##
methylation<-methylation[-which(is.na(methylation[,5])),] 

## ---- warning=FALSE, tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=60), eval=T----
## Load fake genes to show expression conversion ##
data(genes_for_conversiontest)
genes[,1]<-convertGeneIds(a=genes[,1], a_type="refseq",b_type="symbol")

## ---- tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=60), eval=FALSE----
#  ## This is just an example of how to pre-process data ##
#  expression<-expression[-which(is.na(expression[,1])),]
#  expression<-split(expression, expression[,1])
#  expression<-lapply(expression, function(i){if(nrow(as.data.frame(i))>1){i<-i[which(i[,3]==min(i[,3],na.rm=T))[1],]}; return(i)})
#  expression<-do.call(rbind, expression)
#  expression<-expression[,-1]
#  expression<-replaceZeros(expression, 2)

## ---- warning=FALSE, tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=60), eval=T----
## Load expression data ##
data(curated_expressiondata)

## View data ##
head(expression_curated)


## ---- tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=60), eval=T----
## Load hg19 gene annotation BED file ##
data(hg19_genes_bed)

## Load histone modification file ##
data(histone_h3k4me1)

## View files ##
head(hg19_genes)
head(h3k4me1)

## ---- tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=50), eval=T----
test_annotation<-makePvalueAnnotation(data=hg19_genes, otherdata=list(h3k4me1=h3k4me1), gene_name_col=5,other_d=5000, promoter_upstream=1000, promoter_downstream=1000) 

## ----  tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=50), eval=T----
test_annotation<-annotateExpression(test_annotation, expression_curated, effect_col=1,pval_col=2)

## ---- tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=45), eval=F----
#  test_annotation<-annotateModification(test_annotation, methylation, weight_by_method="Stouffer",
#                                        weight_by=c(promoter="distance",body="distance",h3k4me1="distance"),
#                                        verbose=TRUE, modCorr=FALSE, modType="methylation")

## ---- tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=50), eval=F, fig.width= 9----
#  ## See expression data ##
#  head(extractExpression(test_annotation))
#  
#  ## See the uncombined p-values for a specific or all modType(s) ##
#  extractModification(test_annotation, modType="methylation")
#  
#  ## See the combined p-value data.frame ##
#  head(extractModSummary(test_annotation))

## ----  tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=35), eval=F----
#  test_annotation<-makePvalueObject(test_annotation, effect_directions=c(methylation_promoter="decrease", methylation_body="decrease", methylation_h3k4me1="bidirectional"))

## ---- echo=FALSE, eval=T-------------------------------------------------
## Because SMITErunSpinglass and SMITEscorePval are computationally intensive we simply load already ran data instead of evaluating the code.
data(test_annotation_score_data)

## ----  tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=35), eval=T----
## Plot density of p-values ##
plotDensityPval(test_annotation, ref="expression")

## ----  tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=35), eval=T, fig.width=9, fig.height=5----
## Normalize the p-values to the range of expression ##
test_annotation<-normalizePval(test_annotation,ref="expression",method="rescale")

## ---- tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=35), eval=T, fig.width=8----
plotCompareScores(test_annotation, x_name="expression", y_name="methylation_promoter")

## ----long-compute-time, tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=45), eval=F----
#  #score with all four features contributing
#  test_annotation<-SMITEscorePval(test_annotation,weights=c(methylation_promoter=.3,methylation_body=.1,expression=.3,methylation_h3k4me1=.3))

## ---- tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=45), eval=F----
#  ## load REACTOME ##
#   load(system.file("data","Reactome.Symbol.Igraph.rda", package="SMITE"))
#  ## Run Spin-glass ##
#  test_annotation<-SMITErunSpinglass(test_annotation, REACTOME,maxsize=50, niter=1000)
#  
#  ## Run goseq on individual modules to determine bias an annotate functions ##
#  test_annotation<-SMITErunGOseq(test_annotation,coverage=read.table(system.file("extdata", "hg19_symbol_hpaii.sites.inbodyand2kbupstream.bed.gz", package="SMITE")),type="kegg")

## ---- tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=60), eval=T, fig.width=10, fig.height=9----
## search goseq output for keywords ##
SMITEsearchGOseq(test_annotation,"cell cycle")
## Draw a network ##
SMITEplotModule(test_annotation, which.network=6,layout="fr", label_scale=T)

## ---- tidy=TRUE, tidy.opts=list(blank=FALSE, width.cutoff=60), eval=T, fig.width=12,fig.height=6----
## Draw a network with goseq analysis ##
SMITEplotModule(test_annotation, which.network=1,layout="fr", goseq=TRUE,label_scale = F)

